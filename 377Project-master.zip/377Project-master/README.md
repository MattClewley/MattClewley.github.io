#Pickup PG

INST 377 Final Group Project: Trash Collection in PG County

Optimized Browsers: Google Chrome or Mozilla Firefox

Heroku Page: *Link to Heroku Page*
User Manuel: *Link for User Manuel*
Developer Guide: *Link to Developer Guide*

Installation Instructions:


